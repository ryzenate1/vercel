import { projectSchema } from './project';
import { testimonialSchema } from './testimonial';

const schemas = [projectSchema, testimonialSchema];

export { schemas };
